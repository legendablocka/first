// Отримуємо всі елементи слайдера
const slides = document.querySelectorAll('.slide');

// Задаємо початковий індекс активного слайда
let currentSlide = 0;

// Функція, яка переключає слайди
function showSlide(index) {
  // Приховуємо всі слайди
  slides.forEach((slide) => {
    slide.classList.remove('active');
  });

  // Показуємо активний слайд
  slides[index].classList.add('active');
}

// Функція, яка автоматично переключає слайди кожні 5 секунд
function autoSlide() {
  // Збільшуємо індекс активного слайда
  currentSlide++;

  // Якщо досягли останнього слайда, повертаємося до першого слайда
  if (currentSlide === slides.length) {
    currentSlide = 0;
  }

  // Показуємо активний слайд
  showSlide(currentSlide);
}

// Запускаємо автоматичний перехід слайдів кожні 5 секунд
setInterval(autoSlide, 5000);

// Показуємо початковий слайд
showSlide(currentSlide);
